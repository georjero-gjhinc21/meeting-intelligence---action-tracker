# AXIOM Executive — Auth + Working Filter Sources

This patch resolves the `React.useQuery is not a function` error and adds:

- **Google SSO sign-in** (with demo fallback if you don't have a Google client ID yet)
- **AXIOM Executive** rebrand (was AXIOM Intelligence)
- **Working Filter Sources dropdown** in the Transcripts page
- **Real Sign Out** that returns you to the sign-in screen
- Re-delivered **MeetingList.tsx** — clean, no `useQuery`, no broken hooks

## About the `React.useQuery is not a function` error

That error is from a regenerated version of `MeetingList.tsx` somewhere in your
build — `useQuery` is a React Query hook that requires `@tanstack/react-query`
and a `QueryClientProvider`. The MeetingList in this patch uses only standard
`useState` / `useEffect` / `useCallback` / `useRef`, so the error goes away once
you replace the file with the version below.

## Files in this batch

### New
- `src/services/authService.ts` — Google Identity Services wrapper
- `src/context/AuthContext.tsx` — auth state + localStorage persistence
- `src/components/SignInScreen.tsx` — sign-in page

### Replaced
- `src/components/Sidebar.tsx` — AXIOM Executive + live user info + working sign out
- `src/App.tsx` — wraps everything in `<AuthProvider>` and gates content behind sign-in
- `src/components/MeetingList.tsx` — adds working Filter Sources dropdown

## How auth works

| Source | Behavior |
|---|---|
| **Google SSO** | Real Google Sign-In via Google Identity Services. Works once `GOOGLE_CLIENT_ID` is set in `.env.local` |
| **Demo Mode** | Signs you in as `george@gjh-inc.com` without contacting Google. Useful when you don't want to set up OAuth yet |
| **Persistence** | Sessions survive refresh via `localStorage`. Sign Out clears it |
| **Sign Out** | The Sign Out button in the sidebar now actually works — clears the session and returns to the sign-in screen |

## Setup

If you already configured `GOOGLE_CLIENT_ID` for the Drive Picker, **SSO works
out of the box** — same client ID covers both. Just make sure
`http://localhost:3000` is in the OAuth client's "Authorized JavaScript origins".

If you haven't, you can:

1. Skip Google setup entirely and use **Demo Mode** to sign in
2. Or follow the Google Cloud setup steps in `googleDriveService.ts` header comments

## Verify it works

After applying:

1. `npm run dev` → open `http://localhost:3000`
2. **Sign-in screen appears** with the AXIOM Executive logo
3. Click **"Continue in Demo Mode"** (or use Google if configured)
4. App opens — sidebar shows your name and email at the bottom
5. Header in the top-right shows your avatar/initials
6. Open **Transcripts** → drop a `.txt` file on the drop zone → confirm the table populates
7. Click **Filter Sources** → pick "Local" → only locally-ingested meetings show
8. Click **Sign Out** in the sidebar → returns to the sign-in screen
9. Refresh during a session → you stay signed in (localStorage persistence)

## Sample test transcript

Save as `daniel-meeting.txt`:

```
Daniel: Quick update on the data warehouse rollout.
George: We're targeting a four-week discovery. Snowflake is the strong default,
but I want to validate against your current Postgres footprint first.
Daniel: Agreed. Can you have a draft architecture by next Friday?
George: Yes, I'll send it Thursday so we have a buffer.
Prabhu: I'll loop in the Salesforce team to map the CRM fields.
```

Drop it on the Transcripts page → ~3 actions get extracted, mapped to roles.
