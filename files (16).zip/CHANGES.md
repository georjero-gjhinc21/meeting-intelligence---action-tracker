# Transcript Ingestion — Apply Guide

This patch makes the **Transcripts** page fully functional: ingest folders/files
from local disk, Google Drive, or Microsoft Teams exports, then run Gemini
extraction to populate the Dashboard, Hierarchy, and Action Tracker.

## What changed

### New files
- `src/context/MeetingsContext.tsx` — shared state for meetings + actions
- `src/services/transcriptService.ts` — file reading, VTT/SRT cleanup, orchestration
- `src/services/googleDriveService.ts` — Google Picker API + Drive OAuth

### Modified files
- `src/types.ts` — added `source`, `transcript`, `errorMessage` fields to `Meeting`
- `src/services/geminiService.ts` — transcript clipping + tighter prompt
- `src/components/MeetingList.tsx` — major rewrite: real ingestion UI, drag-drop, progress
- `src/components/Dashboard.tsx` — reads from context instead of mocks
- `src/components/ActionExtraction.tsx` — reads from context instead of mocks
- `src/App.tsx` — wraps tree in `<MeetingsProvider>`
- `vite.config.ts` — exposes `GOOGLE_API_KEY` / `GOOGLE_CLIENT_ID` to client
- `.env.example` — documents the new env vars

### Unchanged
- `src/constants.ts` — still seeds the initial mock data (used as defaults)
- `src/components/HierarchyView.tsx`, `Sidebar.tsx`, `SalesforceSync.tsx`, `ActionDetailModal.tsx`, `MeetingList.tsx` types, etc.

## How each source works

| Source | Status | Notes |
|---|---|---|
| **Local Files** | ✅ Fully working | Picks `.txt`, `.vtt`, `.srt`, `.md`, `.json` |
| **Local Folder** | ✅ Fully working | Recursive scan via `webkitdirectory` |
| **Drag & Drop** | ✅ Fully working | Drop folders or files anywhere on the page's drop zone |
| **Google Drive** | ✅ Working with setup | Real Google Picker — needs API key + OAuth client ID |
| **Microsoft Teams** | ⚠️ Manual export | Teams transcripts download as `.vtt` — upload them via the Teams card |

### Why Teams isn't a direct connector
Real Microsoft Graph integration requires registering an Azure AD app and
admin consent, which can't be set up programmatically from this project.
The honest path is: in Teams → recording → "Download transcript" → drop the
`.vtt` file into the Teams card here. The pipeline tags it with the right
source automatically.

## Setup steps

### 1. Drop in the new files
Copy everything in `src/` to your project, replacing existing files.
Replace `vite.config.ts` and `.env.example` at the project root.

### 2. (Optional) Configure Google Drive
If you want real Google Drive ingestion:

1. Go to https://console.cloud.google.com
2. Create / select a project
3. **APIs & Services → Library** → enable **Google Picker API** and **Google Drive API**
4. **APIs & Services → Credentials** → **Create Credentials**:
   - **API key** — restrict by HTTP referrer to `http://localhost:3000/*` and your prod origin
   - **OAuth 2.0 Client ID** — type "Web application", add `http://localhost:3000` to Authorized JavaScript origins
5. Add to your `.env.local`:
   ```
   GOOGLE_API_KEY="your-api-key"
   GOOGLE_CLIENT_ID="123456-abc.apps.googleusercontent.com"
   ```
6. Restart `npm run dev`

If you skip this step, clicking "Google Drive" falls back to the local file picker
with a friendly notice.

### 3. Run
```
npm run dev
```

## Try it

1. Open **Transcripts** in the sidebar
2. Click **Local Files** (or drag a `.vtt` onto the drop zone)
3. Watch the progress banner; the meeting appears in the table with status
   `Processing → Processed`
4. Switch to **Dashboard** — the new meeting and its extracted actions are there
5. Switch to **Action Tracker** — the new actions are filterable by role

## Sample transcript for testing

If you don't have one handy, save this as `test.txt`:

```
Daniel: Welcome everyone. Quick update on the data warehouse rollout.
George: We're targeting a four-week discovery. Snowflake is the strong default,
but I want to validate against your current Postgres footprint first.
Daniel: Agreed. Can you have a draft architecture by next Friday?
George: Yes, I'll send it Thursday so we have a buffer.
Prabhu: I'll loop in our Salesforce team to map the CRM fields.
Daniel: Perfect. The bigger ask is the email triage agent — high-priority for
operations. Let's make that the second use case after the warehouse is stable.
```

You should see ~3-4 actions extracted, mapped to roles like CEO/COO/CIO with
"Project" or "Task" levels.
